<?php
/**
 * BuddyBoss Performance component admin screen.
 *
 * @since   BuddyBoss 1.6.0
 * @package BuddyBoss\Performance
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

