<?php
/**
 * BuddyBoss Performance Filters.
 *
 * @package BuddyBoss\Performance\Filter
 * @since BuddyBoss 1.5.7
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
