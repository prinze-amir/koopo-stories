#	wp bp signup generate

Generate random signups.

## OPTIONS

[--count=&lt;number&gt;]
: How many signups to generate.
\---
default: 100
\---

## EXAMPLE

    $ wp bp signup generate --count=50
