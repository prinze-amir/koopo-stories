#	wp bp email reinstall

Reinstall BuddyPress default emails.

## OPTIONS

[--yes]
: Answer yes to the confirmation message.

## EXAMPLE

    $ wp bp email reinstall --yes
    Success: Emails have been successfully reinstalled.
