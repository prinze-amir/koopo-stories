#	wp bp signup activate

Activate a signup.

## OPTIONS

&lt;signup-id&gt;
: Identifier for the signup. Can be a signup ID, an email address, or a user_login.

## EXAMPLE

    $ wp bp signup activate ee48ec319fef3nn4
    Success: Signup activated, new user (ID #545).
