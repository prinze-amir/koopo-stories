# wp bp activity

Create an activity item.

### EXAMPLES

    # Create an activity item.
    $ wp bp activity create --is-spam=1
    Success: Successfully created new activity item (ID #5464)

    # Get cache.
    $ wp bp activity add --component=groups --user-id=10
    Success: Successfully created new activity item (ID #48949)


